/**
 * 
 */
/**
 * @author pramod
 *
 */
module Day1 {
}