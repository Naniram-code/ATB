package test;

public class Main {

	
		public static void main(String[] arg) {
			
			// ++ and --
			// pre and post
			System.out.println((10 - 4) + 3 *4);
		}
	
}
