# Automation Tester Blueprint Notes
Created by Pramod Dutta


## Core java and RestAssured Notes

#### Core Java and other
  - Variables
  - Data Types
  - Loops and Flow
  - Static block,methods,classes
  - Exceptions
  - Strings, Wrapper Classes, Generics
  - OOPs
  - Collections Framework
    - List
    - Map
    - Set
    - Queue
  - Multithreading
  - Design Patterns
    - Single Pattern
    - Adaptor

#### Rest Assured