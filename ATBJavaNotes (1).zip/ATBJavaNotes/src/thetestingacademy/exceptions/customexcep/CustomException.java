package thetestingacademy.exceptions.customexcep;

public class CustomException extends Exception {
        public CustomException(String msg){
            super(msg);
        }
}
