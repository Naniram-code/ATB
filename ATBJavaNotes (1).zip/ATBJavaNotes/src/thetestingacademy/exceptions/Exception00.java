package thetestingacademy.exceptions;

public class Exception00 {
    public static void main(String[] args) {
        extracted();
    }

    private static void extracted() {
        String name = null;
        name.length();
    }
}
