A program is a set of instructions
A process is a program in execution
Thread is the smallest unit of execution in a process.


![alt text](https://3.bp.blogspot.com/-oGMFihjHTIs/VoFNwwG_3qI/AAAAAAAAEbQ/0DUv4DmhG9A/w1200-h630-p-k-no-nu/Process%2Bvs%2BThread%2Bin%2BJava.jpg)


Benefits of Threads

- Higher throughput
- Responsive applications
- Efficient utilization of resources

Problems with Threads

- Usually very hard to find bugs
- Higher cost of code maintenance
- Increased utilization of system resources
- Programs may experience slowdown 