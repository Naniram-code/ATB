package thetestingacademy.problem.arraysproblem;

public class GroupAnagrams {

    public static void main(String[] args) {

        /**
         * "cat", "dog", "tac", "god", "act",  "tom marvolo riddle ","abc", "def",  "cab", "fed", "clint eastwood ", "i am lord voldemort", "elvis", "old west action",  "lives"
         *  "[cat, tac, act][abc, cab][def, fed][clint eastwood , old west action][tom marvolo riddle , i am lord voldemort][elvis, lives][dog, god]"
         *
         */





    }
}
