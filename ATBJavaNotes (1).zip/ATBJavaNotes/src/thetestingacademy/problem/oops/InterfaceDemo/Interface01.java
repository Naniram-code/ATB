package thetestingacademy.problem.oops.InterfaceDemo;

public class Interface01 {

    public static void main(String[] args) {
        System.out.println(H.a);
    }
}

interface H{
    // Only Static variables
    int a =10;
    int b = 20;
    void m1();
}
