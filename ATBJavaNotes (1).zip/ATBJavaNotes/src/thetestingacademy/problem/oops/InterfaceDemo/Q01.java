package thetestingacademy.problem.oops.InterfaceDemo;

public class Q01 {

    public static void main(String args[]) {
        Pra ref = new Pra();
        System.out.println("Done");
    }
}

class Pra {
}
