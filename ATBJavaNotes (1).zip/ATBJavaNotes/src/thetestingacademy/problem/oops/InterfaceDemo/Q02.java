package thetestingacademy.problem.oops.InterfaceDemo;

public class Q02 {
    public static void main(String args[]) {
        AA ref = new CC();
        System.out.println("Done");
    }
}

class AA {
}

class BB extends AA {
}

class CC extends BB {
}

