package thetestingacademy.problem.oops.InterfaceDemo;

public class Interface04 {
    public static void main(String args[]) {
        System.out.println("Hello Solve Me!");
    }
}

interface Inter1 {
    void m1();

    public abstract void m2();

    int A = 10;
    public final int B = 20;
}

//class Hello implements Inter1 {
//
//}
