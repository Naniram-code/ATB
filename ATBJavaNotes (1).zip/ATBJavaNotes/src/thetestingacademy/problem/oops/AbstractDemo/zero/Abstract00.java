package thetestingacademy.problem.oops.AbstractDemo.zero;
/*
* Abstract class
*
* */



//public class Abstract00 {
//    public static void main(String[] args) {
//        Person p = new Student();
//        p.eat();
//        p.say();
//    }
//}
//
//abstract class Person {
//    abstract void say();
//    void eat(){
//        System.out.println("Hello eat from Person");
//    };
//}
//
//class Student extends Person{
//    @Override
//    void say() {
//        System.out.println("Student eat()");
//    }
//}
