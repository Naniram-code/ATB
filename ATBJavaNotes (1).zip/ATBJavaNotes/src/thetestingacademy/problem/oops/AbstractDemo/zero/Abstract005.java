package thetestingacademy.problem.oops.AbstractDemo.zero;

//abstract class Abstract005 {
class Abstract005 {
    public static void main(String[] args) {
        System.out.println("Main Abstract!!");
    }
}
