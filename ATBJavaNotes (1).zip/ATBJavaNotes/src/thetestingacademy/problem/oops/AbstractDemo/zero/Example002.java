package thetestingacademy.problem.oops.AbstractDemo.zero;

public class Example002 {
    public static void main(String[] args) {
        System.out.println("Concept #1");
    }
}

//abstract class Shape
//{
//    abstract void area();
//}
//class Square extends Shape{ }
