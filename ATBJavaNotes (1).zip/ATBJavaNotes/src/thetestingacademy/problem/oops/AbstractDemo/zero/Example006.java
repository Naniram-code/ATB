package thetestingacademy.problem.oops.AbstractDemo.zero;

public class Example006 {
    public static void main(String[] args) {
//        A a = new C();
    }
}


abstract class A {
    abstract void m1();
}

abstract class B extends A {
//    void m1(){
//    }
}

//class C extends B{}
//