package thetestingacademy.oops.inheritence.example.Multilevel;

public class MainClass {
    public static void main(String[] args) {
        Tesla tesla = new Tesla(300);
        tesla.topSpeed();
    }
}
