package thetestingacademy.oops.inheritence.example.Multilevel;

public class Tesla extends Car {

    Tesla(int i){
        super(i);
    }
}
