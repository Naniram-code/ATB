package thetestingacademy.oops.inheritence.example.Hierarchical;

class Vehicle {

    void vehicleHasTopSpeed(){
        System.out.println("Yeah from "+getClass().getSimpleName());
    }
}
