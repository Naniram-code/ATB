package thetestingacademy.oops.inheritence.example.Hierarchical;

public class Truck extends Vehicle {
    Truck(){
        super.vehicleHasTopSpeed();
    }
}
