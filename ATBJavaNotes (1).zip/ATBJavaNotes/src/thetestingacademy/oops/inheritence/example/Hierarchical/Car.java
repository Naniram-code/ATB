package thetestingacademy.oops.inheritence.example.Hierarchical;

public class Car extends Vehicle{

    Car(){
        super.vehicleHasTopSpeed();
    }
}
