package thetestingacademy.oops.inheritence.example.Hierarchical;

public class MainClass {

    //Hierarchical
    //Car is Vehicle
    // Truck is Vehicle Too

    public static void main(String[] args) {
        new Car();
        new Truck();
    }




}
