package thetestingacademy.oops.inheritence.example.SingleInheritance;

public class MainClass {

    public static void main(String[] args) {

        Java java = new Java(18,"RK","Lambda Expression");
        java.printDetails();



    }
}
