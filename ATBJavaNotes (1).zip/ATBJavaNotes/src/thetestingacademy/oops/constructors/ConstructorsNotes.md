Constructor is used to construct the object of a class.

- A constructor’s name must be exactly the same as the name of its class.
- constructor is a special method because it does not have a return type


- Default Constructor
- Param Constructor
- This Demo
- Copy Constructor in Java