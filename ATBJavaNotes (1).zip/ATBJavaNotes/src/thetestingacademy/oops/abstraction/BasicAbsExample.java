package thetestingacademy.oops.abstraction;

public class BasicAbsExample {

    public static void main(String[] args) {
        int min = Math.min(15,18);     //find min of two numbers
        double square = Math.pow(2,2); //calculate the power of a number

        System.out.println("The min of 15 & 18 is: " + min);
        System.out.println("The square of 2 is: " + square);
    }
}
