//package thetestingacademy.oops.abstraction.interfaceDemo.staticDemo;
//
//public class Test {
//}
//
//public class Car implements Vehicle {
//
//    // can't
////    @Override
////    public void cleanVehicle() {
////        System.out.println("Cleaning the vehicle");
////    }
//
//    public static void main(String args[]) {
//        Car car = new Car();
//        //car.cleanVehicle();
//
//    }
//}
//
//interface Vehicle {
//
//    static void cleanVehicle(){
//        System.out.println("I am cleaning vehicle");
//    }
//}
