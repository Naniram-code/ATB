package thetestingacademy.oops.abstraction.interfaceDemo;

public class Bird implements ICanFly{
    @Override
    public void fly() {
        System.out.println("Bird can Fly");
    }
}
