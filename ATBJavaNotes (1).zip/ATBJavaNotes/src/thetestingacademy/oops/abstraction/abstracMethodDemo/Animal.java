package thetestingacademy.oops.abstraction.abstracMethodDemo;

public abstract class Animal {

    abstract void say();
}
