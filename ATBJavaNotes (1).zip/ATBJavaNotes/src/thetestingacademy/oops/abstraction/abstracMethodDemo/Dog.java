package thetestingacademy.oops.abstraction.abstracMethodDemo;

public class Dog extends Animal{
    @Override
    void say() {
        System.out.println("wowowowow");
    }
}
