package thetestingacademy.oops.abstraction.abstracMethodDemo;

public class MainClass {

    public static void main(String[] args) {
        new Meow().say();
        new Dog().say();
    }


}
