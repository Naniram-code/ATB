### Abstraction

showing only the essential features of an object to the user and hiding the inner details to reduce complexity.

TV Vol Up
Car Driving


Math.min() class

### How to achieve abstraction.

Abstract Classes
Interfaces

#### Abstract methods
public abstract void methodName(parameter(s));

#### Abstract class
abstract class ClassName {

// Implementation here

}

#### An interface is just like a class and specifies the behavior that a class must implement.

interface interfaceName {

// Code goes here

}

An interface can have:

- abstract method(s)
- default method(s)
- static method(s)
- private method(s)
- private static method(s)
- public static final variable(s)

Interfaces allow us to achieve 100% abstraction.
Interfaces can be used to achieve multiple inheritance.