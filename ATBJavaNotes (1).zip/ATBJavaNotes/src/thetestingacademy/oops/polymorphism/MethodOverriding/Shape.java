package thetestingacademy.oops.polymorphism.MethodOverriding;

public class Shape  {

    public double getArea(){
        System.out.println("Area will be printed for Shape");
        return 0;
    }

}
