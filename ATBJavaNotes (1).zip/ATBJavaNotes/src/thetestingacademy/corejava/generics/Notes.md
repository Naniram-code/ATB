Generics are used to create Generic Classes and Methods
 which can work with different Types(Classes)


