package thetestingacademy.corejava.Wrapper.WrapperDemo;

public class WP02 {

    public static void main(String[] args) {
        // Primitive to String
        int x = 123;
        // String st1 = x;
        // String st1 = (String)x;
        // String st1 = x+"";
        // Static value of Method
        // String s1 = String.valueOf(x);
        // Using the Wrapper Class
        //String st1 = Integer.toString(x);
        //double d = 90.87;
        //String st2 = String.valueOf(d);
        //String st2 = Double.toString(d);
        //boolean b = true;
//        String st3 = String.valueOf(b);
//        System.out.println(st3);

        // Primitive to String
        // Using valueOf()
        // toString() of wrapper

    }
}
