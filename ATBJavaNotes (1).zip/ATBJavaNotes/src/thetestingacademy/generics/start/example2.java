package thetestingacademy.generics.start;

public class example2 {
}
