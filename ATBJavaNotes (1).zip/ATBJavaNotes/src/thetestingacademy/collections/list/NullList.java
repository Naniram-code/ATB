package thetestingacademy.collections.list;

import java.util.ArrayList;
import java.util.List;

public class NullList {
    public static void main(String[] args) {
        List stringList = null;
        stringList.add(200);
    }
}
