package thetestingacademy.collections.set;
import java.util.Set;
import java.util.TreeSet;

public class TreeSet00 {

    public static void main(String[] args) {
        Set<Integer> numbers = new TreeSet<>(Set.of(12,34,32,345));




    }
}
