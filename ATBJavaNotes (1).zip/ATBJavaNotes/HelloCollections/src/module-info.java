/**
 * 
 */
/**
 * @author pramod
 *
 */
module HelloCollections {
}